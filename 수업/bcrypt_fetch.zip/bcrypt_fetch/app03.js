const express = require("express");

const app = express();

app.set("views", __dirname + "/views");
app.set("view engine", "ejs");

let = members = [
    {id : "aaa1", pwd : "aaa", name : "홍길동a" , addr : "a산골짜기"},
    {id : "bbb1", pwd : "bbb", name : "홍길동b" , addr : "b산골짜기"},
    {id : "ccc1", pwd : "ccc", name : "홍길동c" , addr : "c산골짜기"},
    {id : "aaa2", pwd : "aaa", name : "홍길동a" , addr : "a산골짜기"},
    {id : "bbb2", pwd : "bbb", name : "홍길동b" , addr : "b산골짜기"},
    {id : "ccc2", pwd : "ccc", name : "홍길동c" , addr : "c산골짜기"},
    {id : "aaa3", pwd : "aaa", name : "홍길동a" , addr : "a산골짜기"},
    {id : "bbb3", pwd : "bbb", name : "홍길동b" , addr : "b산골짜기"},
    {id : "ccc3", pwd : "ccc", name : "홍길동c" , addr : "c산골짜기"},
    {id : "aaa4", pwd : "aaa", name : "홍길동a" , addr : "a산골짜기"},
    {id : "bbb4", pwd : "bbb", name : "홍길동b" , addr : "b산골짜기"},
    {id : "ccc4", pwd : "ccc", name : "홍길동c" , addr : "c산골짜기"},
    {id : "aaa5", pwd : "aaa", name : "홍길동a" , addr : "a산골짜기"},
    {id : "bbb5", pwd : "bbb", name : "홍길동b" , addr : "b산골짜기"},
    {id : "ccc5", pwd : "ccc", name : "홍길동c" , addr : "c산골짜기"},
    {id : "aaa6", pwd : "aaa", name : "홍길동a" , addr : "a산골짜기"},
    {id : "bbb6", pwd : "bbb", name : "홍길동b" , addr : "b산골짜기"},
    {id : "ccc6", pwd : "ccc", name : "홍길동c" , addr : "c산골짜기"},
    {id : "aaa7", pwd : "aaa", name : "홍길동a" , addr : "a산골짜기"},
    {id : "bbb7", pwd : "bbb", name : "홍길동b" , addr : "b산골짜기"},
    {id : "ccc7", pwd : "ccc", name : "홍길동c" , addr : "c산골짜기"},
]

app.get("/", (req, res)=>{
    res.render("index");
})
app.get("/get_members", (req, res)=>{
    res.json( members );
})
const bodyParser = require("body-parser");
app.use( bodyParser.json() );
app.post("/register",(req, res)=>{
    console.log( "req.body : " , req.body )
    members = members.concat(req.body);
    res.json( 1 );
})
app.get("/search/:id", (req, res)=>{
    console.log( req.params );
    const result = members.filter(mem=> mem.id === req.params.id)
    console.log( "result : ", result );
    res.json( result[0] );
})
app.put("/modify", (req, res)=>{
    //update members set name=?, addr=?
    members = members.filter( mem => mem.id !== req.body.id )
    members = members.concat( req.body );
    res.json(1);
})

app.delete("/delete", (req, res)=>{
    //de fr table where id=id;
    members = members.filter( mem => mem.id !== req.body.id );
    res.json(1)
})


app.get("/register_view", (req, res)=>{
        res.render("register_view");
    })  
app.get("/idcheck/:id", (req, res)=>{
        console.log(req.params.id);
        let result = members.filter( (mem) => mem.id === req.params.id );
        console.log("result : ",result);
        if(result.length === 0){
            console.log("undefined...");
            result = 0;
        }
        res.json(result);   
    } ); 

let cnt = 0;
app.get("/view_member", (req, res)=>{
    cnt = 0
    res.render("view_member");
});

app.get("/view", (req, res)=>{
    let number = cnt;
    cnt += 3;
    let result = [];
    for( ; number < cnt ; number++){
        result = result.concat( members[number] );
    }
    res.json( result );
});
app.listen(3000,()=>console.log("3000 실행..."));